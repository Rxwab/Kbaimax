interface Window {
  SpeechRecognition: any
  webkitSpeechRecognition: any
}
