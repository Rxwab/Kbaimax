import { type NextRequest, NextResponse } from "next/server"
import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"

export async function POST(req: NextRequest) {
  try {
    const { messages } = await req.json()

    if (!messages || !Array.isArray(messages) || messages.length === 0) {
      return NextResponse.json({ error: "Invalid request: messages array is required" }, { status: 400 })
    }

    // Format the conversation for the AI
    const conversation = messages
      .map((msg: any) => `${msg.role === "user" ? "User" : "Assistant"}: ${msg.content}`)
      .join("\n")

    // Generate a response using the AI SDK
    const { text } = await generateText({
      model: openai("gpt-4o"),
      system:
        "You are KBAi, an advanced AI assistant that understands user queries, searches for information, and provides helpful responses. You are knowledgeable, friendly, and concise.",
      prompt: `${conversation}\n\nAssistant:`,
    })

    return NextResponse.json({ response: text })
  } catch (error) {
    console.error("Error in chat API:", error)
    return NextResponse.json({ error: "Failed to generate response" }, { status: 500 })
  }
}
