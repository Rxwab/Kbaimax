import type { Metadata } from "next"
import { KBAiChat } from "@/components/kbai-chat"
import { KBAiHeader } from "@/components/kbai-header"
import { KBAiFeatures } from "@/components/kbai-features"

export const metadata: Metadata = {
  title: "KBAi - Advanced AI Assistant",
  description: "An intelligent AI assistant that understands you and learns from interactions",
}

export default function HomePage() {
  return (
    <div className="flex min-h-screen flex-col">
      <KBAiHeader />
      <main className="flex-1 container mx-auto px-4 py-8">
        <section className="mb-12 text-center">
          <h1 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-purple-600 to-blue-500 bg-clip-text text-transparent mb-4">
            Meet KBAi
          </h1>
          <p className="text-xl md:text-2xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            Your intelligent assistant that understands you, learns from interactions, and provides helpful information
            from across the web.
          </p>
        </section>

        <KBAiFeatures />

        <section className="mt-12 max-w-4xl mx-auto">
          <h2 className="text-2xl font-bold mb-6 text-center">Start a Conversation</h2>
          <KBAiChat />
        </section>
      </main>
      <footer className="py-6 border-t border-gray-200 dark:border-gray-800">
        <div className="container mx-auto px-4 text-center text-gray-500 dark:text-gray-400">
          <p>© {new Date().getFullYear()} KBAi. All rights reserved.</p>
        </div>
      </footer>
    </div>
  )
}
