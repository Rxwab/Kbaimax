"use client"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { Mic, MicOff, Send, Loader2, Camera } from "lucide-react"
import { Avatar } from "@/components/ui/avatar"
import { cn } from "@/lib/utils"
import type { SpeechRecognition } from "web-speech-api"

type Message = {
  id: string
  role: "user" | "assistant"
  content: string
  timestamp: Date
}

export function KBAiChat() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "welcome",
      role: "assistant",
      content: "Hello! I'm KBAi, your intelligent assistant. How can I help you today?",
      timestamp: new Date(),
    },
  ])
  const [input, setInput] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [isListening, setIsListening] = useState(false)
  const [isCameraActive, setIsCameraActive] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const videoRef = useRef<HTMLVideoElement>(null)

  // Scroll to bottom of messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  // Handle speech recognition
  useEffect(() => {
    let recognition: SpeechRecognition | null = null

    if (isListening) {
      try {
        recognition = window.SpeechRecognition || window.webkitSpeechRecognition
        recognition.continuous = true
        recognition.interimResults = true

        recognition.onresult = (event) => {
          const transcript = Array.from(event.results)
            .map((result) => result[0])
            .map((result) => result.transcript)
            .join("")

          setInput(transcript)
        }

        recognition.start()
      } catch (error) {
        console.error("Speech recognition not supported:", error)
        setIsListening(false)
      }
    }

    return () => {
      if (recognition) {
        recognition.stop()
      }
    }
  }, [isListening])

  // Handle camera access
  useEffect(() => {
    let stream: MediaStream | null = null

    const setupCamera = async () => {
      if (isCameraActive && videoRef.current) {
        try {
          stream = await navigator.mediaDevices.getUserMedia({ video: true })
          videoRef.current.srcObject = stream
        } catch (error) {
          console.error("Error accessing camera:", error)
          setIsCameraActive(false)
        }
      } else if (!isCameraActive && stream) {
        stream.getTracks().forEach((track) => track.stop())
      }
    }

    setupCamera()

    return () => {
      if (stream) {
        stream.getTracks().forEach((track) => track.stop())
      }
    }
  }, [isCameraActive])

  const handleSendMessage = async () => {
    if (!input.trim()) return

    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: input,
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setIsLoading(true)

    // Simulate AI processing and response
    setTimeout(() => {
      const responses = [
        "I understand what you're asking. Let me search for that information for you.",
        "That's an interesting question! Based on my knowledge and web search, I can tell you that...",
        "I've analyzed your request and found some relevant information that might help.",
        "Let me process that. According to recent information I've found...",
        "I'm learning from our conversation. Here's what I can tell you about that topic...",
      ]

      const randomResponse = responses[Math.floor(Math.random() * responses.length)]

      const assistantMessage: Message = {
        id: Date.now().toString(),
        role: "assistant",
        content: randomResponse,
        timestamp: new Date(),
      }

      setMessages((prev) => [...prev, assistantMessage])
      setIsLoading(false)
    }, 1500)
  }

  const toggleListening = () => {
    setIsListening(!isListening)
  }

  const toggleCamera = () => {
    setIsCameraActive(!isCameraActive)
  }

  return (
    <div
      id="chat"
      className="flex flex-col h-[600px] border border-gray-200 dark:border-gray-800 rounded-lg overflow-hidden"
    >
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((message) => (
          <div key={message.id} className={cn("flex", message.role === "user" ? "justify-end" : "justify-start")}>
            <div className="flex items-start max-w-[80%]">
              {message.role === "assistant" && (
                <Avatar className="h-8 w-8 mr-2">
                  <div className="bg-gradient-to-r from-purple-600 to-blue-500 h-full w-full flex items-center justify-center text-white font-bold">
                    K
                  </div>
                </Avatar>
              )}
              <Card
                className={cn(
                  "p-3",
                  message.role === "user" ? "bg-purple-600 text-white" : "bg-gray-100 dark:bg-gray-800",
                )}
              >
                <p>{message.content}</p>
                <div
                  className={cn(
                    "text-xs mt-1",
                    message.role === "user" ? "text-purple-200" : "text-gray-500 dark:text-gray-400",
                  )}
                >
                  {message.timestamp.toLocaleTimeString([], {
                    hour: "2-digit",
                    minute: "2-digit",
                  })}
                </div>
              </Card>
              {message.role === "user" && (
                <Avatar className="h-8 w-8 ml-2">
                  <div className="bg-gray-300 dark:bg-gray-700 h-full w-full flex items-center justify-center text-gray-600 dark:text-gray-300 font-bold">
                    U
                  </div>
                </Avatar>
              )}
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex justify-start">
            <div className="flex items-start max-w-[80%]">
              <Avatar className="h-8 w-8 mr-2">
                <div className="bg-gradient-to-r from-purple-600 to-blue-500 h-full w-full flex items-center justify-center text-white font-bold">
                  K
                </div>
              </Avatar>
              <Card className="p-3 bg-gray-100 dark:bg-gray-800">
                <div className="flex items-center space-x-2">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  <span>KBAi is thinking...</span>
                </div>
              </Card>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {isCameraActive && (
        <div className="relative h-32 bg-black">
          <video ref={videoRef} autoPlay muted className="absolute inset-0 w-full h-full object-cover" />
          <div className="absolute bottom-2 right-2">
            <Button size="sm" variant="destructive" onClick={toggleCamera} className="bg-red-600 hover:bg-red-700">
              Close Camera
            </Button>
          </div>
        </div>
      )}

      <div className="border-t border-gray-200 dark:border-gray-800 p-4">
        <div className="flex items-center space-x-2">
          <Button
            variant="outline"
            size="icon"
            onClick={toggleCamera}
            className={cn(isCameraActive && "bg-purple-100 dark:bg-purple-900")}
          >
            <Camera className="h-5 w-5" />
          </Button>
          <Button
            variant="outline"
            size="icon"
            onClick={toggleListening}
            className={cn(isListening && "bg-purple-100 dark:bg-purple-900")}
          >
            {isListening ? <MicOff className="h-5 w-5 text-red-500" /> : <Mic className="h-5 w-5" />}
          </Button>
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Type your message..."
            className="flex-1"
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault()
                handleSendMessage()
              }
            }}
          />
          <Button onClick={handleSendMessage} disabled={!input.trim() || isLoading}>
            {isLoading ? <Loader2 className="h-5 w-5 animate-spin" /> : <Send className="h-5 w-5" />}
          </Button>
        </div>
      </div>
    </div>
  )
}
