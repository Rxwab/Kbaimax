import { Brain, Search, Mic, Video, Smile } from "lucide-react"

export function KBAiFeatures() {
  const features = [
    {
      icon: <Brain className="h-8 w-8 text-purple-600" />,
      title: "Intelligent Learning",
      description: "KBAi learns from every interaction, continuously improving its responses and understanding.",
    },
    {
      icon: <Search className="h-8 w-8 text-purple-600" />,
      title: "Web Search Integration",
      description: "Searches Google and YouTube to provide up-to-date information and relevant content.",
    },
    {
      icon: <Mic className="h-8 w-8 text-purple-600" />,
      title: "Voice Interaction",
      description: "Talk to KBAi naturally and hear responses in a human-like voice.",
    },
    {
      icon: <Video className="h-8 w-8 text-purple-600" />,
      title: "Video Understanding",
      description: "Analyzes video content to understand context and provide relevant information.",
    },
    {
      icon: <Smile className="h-8 w-8 text-purple-600" />,
      title: "Emotion Recognition",
      description: "Understands facial expressions and adapts responses to your emotional state.",
    },
  ]

  return (
    <section id="features" className="py-12">
      <h2 className="text-3xl font-bold text-center mb-12">Key Features</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {features.map((feature, index) => (
          <div
            key={index}
            className="border border-gray-200 dark:border-gray-800 rounded-lg p-6 hover:shadow-md transition-shadow"
          >
            <div className="mb-4">{feature.icon}</div>
            <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
            <p className="text-gray-600 dark:text-gray-400">{feature.description}</p>
          </div>
        ))}
      </div>
    </section>
  )
}
